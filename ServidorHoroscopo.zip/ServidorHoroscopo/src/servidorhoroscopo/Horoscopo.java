/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorhoroscopo;
import interfaz.irHoroscopo;
import java.rmi.RemoteException;
import java.sql.*;

/**
 *
 * @author javier
 */
public class Horoscopo implements irHoroscopo{
    public Horoscopo(){
        super();
    }

    /**
     *
     * @param d
     * @param m
     * @return
     * @throws RemoteException
     */
    @Override
    public String CalculadoraHoroscopo(int d, int m) throws RemoteException {
       
    
      String cadena = null;
              String cadena1;

			
	  if(d>=20 && m==1){
	       	//Enero 20 – Febrero 18-> acuario
	       cadena="Su signo es acuario";
    	           }
		else if(d<=18 && m==2){
	        //Enero 20 – Febrero 18-> acuario
	        cadena="Su signo es acuario";
		}
		
		
		
		
		else if(d>=19 && m==2){
	     	//Febrero 19 – Marzo 20
	        cadena="Su signo es piscis";
    	}
	    
	    else if(d<=20 && m==3){
			//Febrero 19 – Marzo 20
	              cadena="Su signo es piscis";
		}
		
		
		
		else if(d>=21 && m==3){
		      //Marzo 21 –Abril 19
	            cadena="Su signo es aries";
      	}
	    else if(d<=19 && m==4){
		    	//Marzo 21 –Abril 19
	            cadena="Su signo es aries";
		}
	
	
	   		
		 else if(d>=20 && m==4){
	          //Abril 20 – Mayo 20-> tauro
	                  cadena="Su signo es tauro";
	    }
	    else if(d<=20 && m==5){
		        //Abril 20 – Mayo 20-> tauro
	                       cadena="Su signo es tauro";
		}
		
		
		else if(d>=21 && m==5){
	        		//Mayo 21 – Junio 20 -> geminis
	                         cadena="Su signo es geminis";
     	}
	    else if(d<=20 && m==6){
		        	//Mayo 21 – Junio 20 -> geminis
	                           cadena="Su signo es geminis";
		}


       	
		else if(d>=21 && m==6){
		        	//Junio 21 – Julio 22-> cancer
	                              cadena="Su signo es cancer";   
    	}	
    	else if(d<=22 && m==7){
		         	//Junio 21 – Julio 22-> cancer
	                        cadena="Su signo es cancer";  
		}
		
		
	     else if(d>=23 && m==7){
		            //Julio 23–Agosto 22-> leo
	                cadena="Su signo es leo"; 
    	}
	    else if(d<=22 && m==8){
	           		  //Julio 23–Agosto 22-> leo
	                    cadena="Su signo es leo"; 
		}
	
	
	  
		else if(d>=23 && m==8){
		       //Agosto 23 – Septiembre 22-> virgo
	                     cadena="Su signo es virgo";
    	}
    	else if(d<=22 && m==9){
			//Agosto 23 – Septiembre 22-> virgo
	                     cadena="Su signo es virgo";
		}
		
		
		
		
		else if(d>=23 && m==9){
		    //Septiembre 23 – Octubre 22-> libra
	               cadena="Su signo es libra";
	    }
	    else if(d<=22 && m==10){
		   //Septiembre 23 – Octubre 22-> libra
	                  cadena="Su signo es libra";
		}
	
	
		else if(d>=23 && m==10){
		    //Octubre 23 – Noviembre 21-> escorpion
	                   cadena="Su signo es escorpion";
	    }
	     else if(d<=21 && m==11){
		  //Octubre 23 – Noviembre 21-> escorpion
	               cadena="Su signo es escorpion";
		}
		
		
		else if(d>=22 && m==11){
		   	//Noviembre 22 - Diciembre 21-> sagitario
	                   cadena="Su signo es sagitario";
     	}
     	else if(d<=22 && m==12){
			//Noviembre 22 - Diciembre 21-> sagitario
	                      cadena="Su signo es sagitario";
		}
	   
	   
		else if(d>=20 && m==1){
		  //Enero 20 – Febrero 18-> acuario
	              cadena="Su signo es acuario";
	    }
	    else if(d<=18 && m==2){
			//Enero 20 – Febrero 18-> acuario
	                   cadena="Su signo es acuario";
		}
	
	
		else if(d>=22 && m==12){
		    //Diciembre 22 – Enero 19-> capricornio
	                    cadena="Su signo es capricornio";
	    }
	    else if(d<=19 && m==1){
			 //Diciembre 22 – Enero 19-> capricornio
	                    cadena="Su signo es capricornio";
		}
	
         cadena1=cadena;
	  return cadena;
        
    }
    
    
    
    //servicio numero 2
    @Override
    public String HoroscopoSemana(int signo) throws RemoteException {
         
       String resultado = null;  
       //Cadena de conexión de MySql, el parametro useSSL es opcional
        String url = "jdbc:mysql://localhost/horoscopo";
        // Cargamos el driver de mysql
        try {
              Class.forName("com.mysql.jdbc.Driver");
        // Creamos el objeto conexion
        Connection conexion = (Connection) DriverManager.getConnection(url, "root", "");
        // Creamos un objeto Statement
        Statement instruccion = conexion.createStatement();

        

// Creamos el switch
        switch(signo){
        
               case 1:
           //piscis
               String sql = "select nombre,color,personalidad,semanal from signo where id_signo=8";
               ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
            }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         break;
         
         
        case 2:
             //tauro
               String sql2 = "select nombre,color,personalidad,semanal from signo where id_signo=10";
               ResultSet result2 = instruccion.executeQuery(sql2);

            if(result2.next()){
               String a1=result2.getString(1);
               String a2=result2.getString(2);
               String a3=result2.getString(3);
               String a4=result2.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result2.close();
               instruccion.close();
               conexion.close();
            
        break;
        
        
        case 3:
             //geminis
               String sql3 = "select nombre,color,personalidad,semanal from signo where id_signo=11";
               ResultSet result3 = instruccion.executeQuery(sql3);

            if(result3.next()){
               String a1=result3.getString(1);
               String a2=result3.getString(2);
               String a3=result3.getString(3);
               String a4=result3.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result3.close();
               instruccion.close();
               conexion.close();
        break;
        
        case 4:
             //cancer
               String sql4 = "select nombre,color,personalidad,semanal from signo where id_signo=12";
               ResultSet result4 = instruccion.executeQuery(sql4);

            if(result4.next()){
               String a1=result4.getString(1);
               String a2=result4.getString(2);
               String a3=result4.getString(3);
               String a4=result4.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result4.close();
               instruccion.close();
               conexion.close();
        break;
        
        case 5:
             //leo
               String sql5 = "select nombre,color,personalidad,semanal from signo where id_signo=1";
               ResultSet result5 = instruccion.executeQuery(sql5);

            if(result5.next()){
               String a1=result5.getString(1);
               String a2=result5.getString(2);
               String a3=result5.getString(3);
               String a4=result5.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result5.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 6:
             //libra
               String sql6 = "select nombre,color,personalidad,semanal from signo where id_signo=3";
               ResultSet result6 = instruccion.executeQuery(sql6);

            if(result6.next()){
               String a1=result6.getString(1);
               String a2=result6.getString(2);
               String a3=result6.getString(3);
               String a4=result6.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result6.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 7:
             //escorpion
               String sql7 = "select nombre,color,personalidad,semanal from signo where id_signo=4";
               ResultSet result7 = instruccion.executeQuery(sql7);

            if(result7.next()){
               String a1=result7.getString(1);
               String a2=result7.getString(2);
               String a3=result7.getString(3);
               String a4=result7.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result7.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 8:
             //sagitario
               String sql8 = "select nombre,color,personalidad,semanal from signo where id_signo=5";
               ResultSet result8 = instruccion.executeQuery(sql8);

            if(result8.next()){
               String a1=result8.getString(1);
               String a2=result8.getString(2);
               String a3=result8.getString(3);
               String a4=result8.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result8.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 9:
             //carpicornio
               String sql9 = "select nombre,color,personalidad,semanal from signo where id_signo=6";
               ResultSet result9 = instruccion.executeQuery(sql9);

            if(result9.next()){
               String a1=result9.getString(1);
               String a2=result9.getString(2);
               String a3=result9.getString(3);
               String a4=result9.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result9.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 10:
             //acuario
               String sql10 = "select nombre,color,personalidad,semanal from signo where id_signo=7";
               ResultSet result10 = instruccion.executeQuery(sql10);

            if(result10.next()){
               String a1=result10.getString(1);
               String a2=result10.getString(2);
               String a3=result10.getString(3);
               String a4=result10.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result10.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 11:
             //aries
               String sql11 = "select nombre,color,personalidad,semanal from signo where id_signo=9";
               ResultSet result11 = instruccion.executeQuery(sql11);

            if(result11.next()){
               String a1=result11.getString(1);
               String a2=result11.getString(2);
               String a3=result11.getString(3);
               String a4=result11.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result11.close();
               instruccion.close();
               conexion.close();
        break;
        
        
         case 12:
             //virgo
               String sql12 = "select nombre,color,personalidad,semanal from signo where id_signo=2";
               ResultSet result12 = instruccion.executeQuery(sql12);

            if(result12.next()){
               String a1=result12.getString(1);
               String a2=result12.getString(2);
               String a3=result12.getString(3);
               String a4=result12.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result12.close();
               instruccion.close();
               conexion.close();
        break;
        }

     
          }
           catch(ClassNotFoundException | SQLException e) {
           e.printStackTrace();
           }
       
         
           
               return resultado;
    }

    


    @Override
    public String CompatibilidadHoroscopo(int s1, int s2) throws RemoteException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        String resultado = null;  
       //Cadena de conexión de MySql, el parametro useSSL es opcional
        String url = "jdbc:mysql://localhost/horoscopo";
        // Cargamos el driver de mysql
        try{
              Class.forName("com.mysql.jdbc.Driver");
        // Creamos el objeto conexion
        Connection conexion = (Connection) DriverManager.getConnection(url, "root", "");
        // Creamos un objeto Statement
        Statement instruccion = conexion.createStatement();
        /********************************************/
        
        //1
        if (s1==1 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=1";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
         
        //2
        else if(s1==1 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=2";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //3
        else if(s1==1 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=3";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //4
        else if(s1==1 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=4";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //5
        else if(s1==1 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=5";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //6
        else if(s1==1 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=6";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //7
        else if(s1==1 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=7";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //8
        else if(s1==1 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=8";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //9 
        else if(s1==1 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=9";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //10
        else if(s1==1 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=10";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //11
        else if(s1==1 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=11";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //12 
        else if(s1==1 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=12";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //13 
        else if(s1==2 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=13";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //14 
        else if(s1==2 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=14";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //15
        else if(s1==2 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=15";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //16
        else if(s1==2 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=16";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //17 
        else if(s1==2 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=17";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //18 
        else if(s1==2 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=18";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //19 
        else if(s1==2 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=19";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //20 
        else if(s1==2 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=20";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //21 
        else if(s1==2 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=21";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //22 
        else if(s1==2 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=22";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //23 
        else if(s1==2 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=23";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //24 
        else if(s1==2 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=24";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //25  
        else if(s1==3 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=25";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //26
        else if(s1==3 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=26";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //27 
        else if(s1==3 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=27";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //28 
        else if(s1==3 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=28";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //29 
        else if(s1==3 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=29";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        // 30
        else if(s1==3 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=30";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //31 
        else if(s1==3 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=31";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //32 
        else if(s1==3 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=32";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //33 
        else if(s1==3 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=33";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //34 
        else if(s1==3 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=34";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //35 
        else if(s1==3 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=35";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //36 
        else if(s1==3 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=36";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //37 
        else if(s1==4 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=37";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //38  
        else if(s1==4 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=38";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //39 
        else if(s1==4 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=39";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //40 
        else if(s1==4 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=40";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //41 
        else if(s1==4 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=41";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //42 
        else if(s1==4 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=42";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //43
        else if(s1==4 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=43";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //44 
        else if(s1==4 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=44";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //45 
        else if(s1==4 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=45";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //46 
        else if(s1==4 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=46";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //47 
        else if(s1==4 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=47";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //48 
        else if(s1==4 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=48";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //49 
        else if(s1==5 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=49";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //50 
        else if(s1==5 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=50";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //51  
        else if(s1==5 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=51";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //52 
        else if(s1==5 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=52";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //53 
        else if(s1==5 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=53";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //54 
        else if(s1==5 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=54";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //55 
        else if(s1==5 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=55";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //56 
        else if(s1==5 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=56";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //57 
        else if(s1==5 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=57";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //58 
        else if(s1==5 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=58";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //59 
        else if(s1==5 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=59";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //60 
        else if(s1==5 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=60";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //61 
        else if(s1==6 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=61";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //62 
        else if(s1==6 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=62";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //63 
        else if(s1==6 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=63";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //64  
        else if(s1==6 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=64";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //65 
        else if(s1==6 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=65";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //66 
        else if(s1==6 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=66";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //67 
        else if(s1==6 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=67";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //68 
        else if(s1==6 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=68";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //69 
        else if(s1==6 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=69";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //70 
        else if(s1==6 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=70";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //71 
        else if(s1==6 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=71";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //72 
        else if(s1==6 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=72";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //73 
        else if(s1==7 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=73";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //74 
        else if(s1==7 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=74";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //75 
        else if(s1==7 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=75";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //76 
        else if(s1==7 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=76";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //77  
        else if(s1==7 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=77";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //78 
        else if(s1==7 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=78";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //79 
        else if(s1==7 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=79";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //80 
        else if(s1==7 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=80";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //81 
        else if(s1==7 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=81";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //82 
        else if(s1==7 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=82";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //83 
        else if(s1==7 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=83";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //84 
        else if(s1==7 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=84";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //85 
        else if(s1==8 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=85";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //86 
        else if(s1==8 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=86";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //87 
        else if(s1==8 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=87";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //88 
        else if(s1==8 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=88";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //89 
        else if(s1==8 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=89";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //90  
        else if(s1==8 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=90";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //91 
        else if(s1==8 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=91";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //92
        else if(s1==8 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=92";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //93
        else if(s1==8 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=93";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //94 
        else if(s1==8 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=94";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //95 
        else if(s1==8 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=95";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //96 
        else if(s1==8 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=96";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //97 
        else if(s1==9 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=97";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //98 
        else if(s1==9 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=98";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //99 
        else if(s1==9 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=99";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //100 
        else if(s1==9 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=100";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //101 
        else if(s1==9 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=101";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //102
        else if(s1==9 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=102";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //103 
        else if(s1==9 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=103";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //104 
        else if(s1==9 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=104";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //105 
        else if(s1==9 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=105";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //106 
        else if(s1==9 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=106";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         
        //107
        else if(s1==9 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=107";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //108 
        else if(s1==9 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=108";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //109 
        else if(s1==10 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=109";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //110 
        else if(s1==10 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=110";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //111 
        else if(s1==10 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=111";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //112 
        else if(s1==10 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=112";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //113 
        else if(s1==10 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=113";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //114 
        else if(s1==10 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=114";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //115 
        else if(s1==10 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=115";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //116  
        else if(s1==10 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=116";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //117 
        else if(s1==10 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=117";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //118 
        else if(s1==10 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=118";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //119 
        else if(s1==10 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=119";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //120 
        else if(s1==10 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=120";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //121 
        else if(s1==11 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=121";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //122 
        else if(s1==11 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=122";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //123 
        else if(s1==11 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=123";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //124 
        else if(s1==11 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=124";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //125 
        else if(s1==11 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=125";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //126 
        else if(s1==11 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=126";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //127 
        else if(s1==11 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=127";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //128 
        else if(s1==11 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=128";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //129  
        else if(s1==11 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=129";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //130 
        else if(s1==11 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=130";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //131 
        else if(s1==11 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=131";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //132 
        else if(s1==11 && s2==12){
        String sql = "select elementos, analisis from comparativa where id_comp=132";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //133 
        else if(s1==12 && s2==1){
        String sql = "select elementos, analisis from comparativa where id_comp=133";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //134 
        else if(s1==12 && s2==2){
        String sql = "select elementos, analisis from comparativa where id_comp=134";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //135 
        else if(s1==12 && s2==3){
        String sql = "select elementos, analisis from comparativa where id_comp=135";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //136 
        else if(s1==12 && s2==4){
        String sql = "select elementos, analisis from comparativa where id_comp=136";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //137 
        else if(s1==12 && s2==5){
        String sql = "select elementos, analisis from comparativa where id_comp=137";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //138 
        else if(s1==12 && s2==6){
        String sql = "select elementos, analisis from comparativa where id_comp=138";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //139 
        else if(s1==12 && s2==7){
        String sql = "select elementos, analisis from comparativa where id_comp=139";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //140 
        else if(s1==12 && s2==8){
        String sql = "select elementos, analisis from comparativa where id_comp=140";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
         //141
        else if(s1==12 && s2==9){
        String sql = "select elementos, analisis from comparativa where id_comp=141";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        
        //142  
        else if(s1==12 && s2==10){
        String sql = "select elementos, analisis from comparativa where id_comp=142";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //143 
        else if(s1==12 && s2==11){
        String sql = "select elementos, analisis from comparativa where id_comp=143";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
        
        //
        else{
        String sql = "select elementos, analisis from comparativa where id_comp=3";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               resultado="\n"+a1+"\n"+a2+"\n";
        }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }

        /*******************************************/
         }
        catch(ClassNotFoundException | SQLException e) {
           e.printStackTrace();
           }
        return resultado;
      
    }

    
    //servicio 4

    /**
     *
     * @param d
     * @param m
     * @param a
     * @param genero
     * @return
     * @throws RemoteException
     */
    @Override
    public String HoroscopoChino(int d,int m,int a,int genero) throws RemoteException {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        String resultado = null;  
       //Cadena de conexión de MySql, el parametro useSSL es opcional
        String url = "jdbc:mysql://localhost/horoscopo";
        // Cargamos el driver de mysql
        try{
              Class.forName("com.mysql.jdbc.Driver");
        // Creamos el objeto conexion
        Connection conexion = (Connection) DriverManager.getConnection(url, "root", "");
        // Creamos un objeto Statement
        Statement instruccion = conexion.createStatement();
        
        
        /********************************************/
     if (a%12==0){
        //perro 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=12";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
     else if(a%12==1){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=11";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==2){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=10";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==3){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=9";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==4){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=8";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==5){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=7";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     
     else if(a%12==6){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=6";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     
     else if(a%12==7){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=5";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==8){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=4";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==9){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=3";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==10){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=2";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else{
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=1";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
        }
        catch(ClassNotFoundException | SQLException e) {
           e.printStackTrace();
           }
        return resultado;
    }   
}
